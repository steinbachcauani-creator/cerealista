# Modelo de site — Cerealista de Cebola

Este é um template simples, responsivo e acessível (HTML, CSS e JS puros) para uma cerealista de cebola no Brasil.

## Como usar
1. Baixe os arquivos e abra `index.html` no navegador.
2. Substitua os campos entre colchetes `[]` pelo conteúdo da sua empresa (nome, cidade, CNPJ, telefones etc.).
3. Troque as imagens em `assets/`:
   - `logo.png` (fundo transparente, ~512x128px)
   - `hero.jpg` (foto de campo/cebola, 1920x1080px)
   - `favicon.png` (512x512px)
4. Ajuste os links de WhatsApp e e-mail no `index.html` e no `script.js`.
5. (Opcional) Publique no Netlify, Vercel, GitHub Pages ou servidor próprio.

## SEO
- Título, descrição e Open Graph prontos para preencher.
- Marcação JSON-LD de `Organization`. Para catálogos maiores, acrescente `Product` por calibre.
- URLs amigáveis podem ser configuradas em um framework (ex.: Next.js) caso deseje evoluir.

## Performance
- Imagens otimizadas (use JPG de qualidade 70–80, WebP/AVIF quando possível).
- `preload` do herói para pintura rápida.
- CSS único e pequeno, sem bibliotecas externas.

## Acessibilidade
- Skip link, contraste adequado, foco visível, labels em formulários e `aria-live` nas respostas.

## Personalização rápida
- Cores em `:root` (variáveis CSS).
- Seções podem ser duplicadas/removidas conforme a necessidade.

## Backend (opcional)
- Troque o `mailto:` por um endpoint real (Node, PHP, etc.).
- No Netlify, você pode ativar formulários adicionando `name="contato"` e um input hidden `form-name`.

---

Feito para acelerar sua presença online e fechar negócios mais rápido. Bons negócios! 🧅
