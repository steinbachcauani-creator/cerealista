// Navegação móvel
const navToggle = document.getElementById('navToggle');
const menu = document.getElementById('menu');
if (navToggle && menu){
  navToggle.addEventListener('click', () => {
    const open = menu.classList.toggle('open');
    navToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
}

// Ano no rodapé
document.getElementById('ano').textContent = new Date().getFullYear();

// Simulador de rastreamento de lote (mock local)
const mockLotes = {
  "LOTE-2025-000123": { origem: "Ituporanga/SC", calibre: "45/50", tipo: "Amarela", data: "2025-07-10", status: "Aprovado" },
  "LOTE-2025-000456": { origem: "Vidal Ramos/SC", calibre: "50/60", tipo: "Roxa", data: "2025-07-22", status: "Aprovado" }
};

function buscarLote(ev){
  ev.preventDefault();
  const cod = document.getElementById('codigoLote').value.trim();
  const out = document.getElementById('resultadoLote');
  if (mockLotes[cod]){
    const l = mockLotes[cod];
    out.innerHTML = `Origem: ${l.origem} • Calibre: ${l.calibre} • Tipo: ${l.tipo} • Data: ${l.data} • Status: ${l.status}`;
  } else {
    out.textContent = "Lote não encontrado. Verifique o código ou fale com nossa equipe.";
  }
  return false;
}

// Formulário de contato — sem backend (gera link mailto)
function enviarContato(ev){
  ev.preventDefault();
  const nome = document.getElementById('nome').value.trim();
  const empresa = document.getElementById('empresa').value.trim();
  const email = document.getElementById('email').value.trim();
  const telefone = document.getElementById('telefone').value.trim();
  const mensagem = document.getElementById('mensagem').value.trim();

  const assunto = encodeURIComponent(`Cotação — ${nome} (${empresa||"Pessoa Física"})`);
  const corpo = encodeURIComponent(
    `Nome: ${nome}\nEmpresa: ${empresa}\nE-mail: ${email}\nTelefone: ${telefone}\n\nMensagem:\n${mensagem}`
  );
  const mailto = `mailto:contato@exemplo.com.br?subject=${assunto}&body=${corpo}`;
  document.getElementById('retornoForm').textContent = "Abrindo seu aplicativo de e-mail com a mensagem...";
  window.location.href = mailto;
  return false;
}
